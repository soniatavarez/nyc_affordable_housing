create function pgaadauth_create_principal(rolename text, isadmin boolean, ismfa boolean) returns text
    language plpgsql
as
$$
    DECLARE securityLabel text := 'aadauth';
    DECLARE createRoleQuery text;
    DECLARE securityLabelQuery text;
    DECLARE query text;
    BEGIN
        createRoleQuery := FORMAT('CREATE ROLE %1$s LOGIN',  quote_ident(roleName));

        IF isAdmin IS TRUE THEN
            createRoleQuery := CONCAT(createRoleQuery,  ' CREATEROLE CREATEDB in role azure_pg_admin');
            securityLabel := CONCAT(securityLabel, ',admin');
        END IF;

        createRoleQuery := CONCAT(createRoleQuery, ';');

        IF isMfa IS TRUE THEN
            securityLabel := CONCAT(securityLabel, ',mfa');
        END IF;

        EXECUTE createRoleQuery;

        securityLabelQuery := FORMAT('SECURITY LABEL for "pgaadauth" on role %1$s is %2$s', quote_ident(roleName) , quote_literal(securityLabel));

        EXECUTE securityLabelQuery;

        RETURN FORMAT('Created role for %1$s', quote_ident(roleName));
    END;
$$;

alter function pgaadauth_create_principal(text, boolean, boolean) owner to azuresu;

