create function pgaadauth_desync_group_members(groupobjectid text) returns void
    language plpgsql
as
$$
    DECLARE groupName text;
    DECLARE groupRoleOid  text;
    DECLARE eachRow RECORD;
    DECLARE query text;
    DECLARE azure_ad_user_roleOid oid;
    DECLARE isCPG boolean := FALSE;
    DECLARE isFlex boolean := FALSE;
    DECLARE adminRoleId text;
    DECLARE adminRoleName text;
    BEGIN
        --- We need the groupName and group's role-oid
        --- given a groupObjectId corresponding to an aad group,
        --- we get group's name and role-oid from the pg_seclabels.
        --- This information is populated ONLY if the group has been onboarded
        --- through the aad methods(create_principle...).
        SELECT
            pg_roles.rolname,
            pg_roles.oid
        INTO groupName, groupRoleOid
        FROM pg_roles
            INNER JOIN pg_seclabels -- The group's aad-oid is part of the label
            ON pg_roles.oid = pg_seclabels.objoid
        WHERE pg_seclabels.label ~ ('oid=' || groupObjectId);

        IF current_user = 'postgres'
        THEN
            isCPG := TRUE;
            adminRoleName := 'postgres';
        ELSIF current_user = 'azuresu' THEN
            isFlex := TRUE;
            adminRoleName := 'azure_pg_admin';
        ELSE
            RAISE EXCEPTION 'This function can only be called by the superuser that is either azuresu(Flex) or postgres(CPG)';
        END IF;

        SELECT pg_roles.oid INTO adminRoleId FROM pg_roles WHERE rolname=adminRoleName;
        SELECT pg_roles.oid INTO azure_ad_user_roleOid FROM pg_roles WHERE rolname='azure_ad_user';

        FOR eachRow IN (
            SELECT
                counted_roles.membershipCount,
                counted_roles.localRolesOid,
                counted_roles.localRoleName,
                (pg_seclabels.label ~ '\,admin') AS isCurrentRoleAdmin
            FROM pg_seclabels
            INNER JOIN (
                SELECT
                    COUNT(*) membershipCount,
                    group_roles.oid localRolesOid,
                    group_roles.rolname localRoleName
                FROM (
                    SELECT
                        pg_roles.oid,
                        pg_roles.rolname
                    FROM pg_roles
                    INNER JOIN pg_auth_members
                        ON pg_roles.oid=pg_auth_members.member
                    WHERE
                        pg_auth_members.roleid=groupRoleOid::oid) group_roles
                INNER JOIN pg_auth_members
                    ON group_roles.oid=pg_auth_members.member
                WHERE
                    pg_auth_members.roleid != azure_ad_user_roleOid::oid AND
                    pg_auth_members.roleid != adminRoleId::oid
                GROUP BY group_roles.oid, group_roles.rolname) counted_roles
            ON pg_seclabels.objoid = counted_roles.localRolesOid
            WHERE
                pg_seclabels.label ~ 'extensionmanaged' AND
                pg_seclabels.label ~ 'aadauth')
        LOOP
            PERFORM pgaadauth_revoke_principal_group_membership(
                groupName::text,
                groupRoleOid::oid,
                groupObjectId::text,
                eachRow.localRoleName::text,
                eachRow.localRolesOid::oid,
                eachRow.isCurrentRoleAdmin::boolean,
                adminRoleName::text,
                adminRoleId::oid,
                eachRow.membershipCount::integer,
                azure_ad_user_roleOid::oid,
                isCPG::boolean);
        END LOOP;

        query := 'DROP ROLE ' || quote_ident(groupName);
        EXECUTE query;
    END;
$$;

alter function pgaadauth_desync_group_members(text) owner to azuresu;

