create function pgaadauth_drop_principal_if_exists(role_name_to_drop text) returns void
    language plpgsql
as
$$
DECLARE
    role_oid OID;
BEGIN
    BEGIN
        -- Get the OID of the role
        SELECT oid INTO role_oid
        FROM pg_roles
        WHERE rolname = role_name_to_drop;

        -- Check if the role is EntraId role
        IF role_oid IS NOT NULL THEN
            -- Check if there are any security labels associated with the role
            IF EXISTS (
                SELECT 1
                FROM pg_shseclabel
                WHERE objoid = role_oid
            ) THEN
                EXECUTE format('DROP ROLE %I', role_name_to_drop);
                RAISE NOTICE 'Role % dropped successfully.', role_name_to_drop;
            ELSE
                RAISE NOTICE 'Given Role % is not an EntraID role.', role_name_to_drop;
            END IF;
        ELSE
            RAISE NOTICE 'Role % does not exist.', role_name_to_drop;
        END IF;
    EXCEPTION
        WHEN others THEN
            RAISE NOTICE 'An error occurred while dropping role %: %', role_name_to_drop, SQLERRM;
    END;
END;
$$;

alter function pgaadauth_drop_principal_if_exists(text) owner to azuresu;

