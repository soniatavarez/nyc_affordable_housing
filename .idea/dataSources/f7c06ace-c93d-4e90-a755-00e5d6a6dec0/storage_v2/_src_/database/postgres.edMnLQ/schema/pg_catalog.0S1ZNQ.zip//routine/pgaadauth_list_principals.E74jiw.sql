create function pgaadauth_list_principals(isadminvalue boolean)
    returns TABLE(rolname name, principaltype text, objectid text, tenantid text, ismfa integer, isadmin integer)
    language plpgsql
as
$$
BEGIN
    RETURN query     
        SELECT
            roles.rolname,
            replace(substring(label from 'type=\w+'), 'type=', '') AS principalType,
            replace(substring(label from 'oid=[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'), 'oid=', '') AS objectId,
            replace(substring(label from 'tenant_id=[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'), 'tenant_id=', '') AS tenantId,
            CASE
                WHEN label LIKE '%,mfa%' THEN 1
                ELSE 0
            END AS isMfa,
            CASE
                WHEN label LIKE '%,admin%' THEN 1
                ELSE 0
            END AS isAdmin
        FROM
            pg_roles roles
        INNER JOIN pg_shseclabel label ON
            roles.oid = label.objoid
            AND label.provider = 'pgaadauth-int'
        WHERE (isAdminValue = true AND label like '%,admin%') 
            OR isAdminValue = false;
END;
$$;

alter function pgaadauth_list_principals(boolean) owner to azuresu;

