create function pgaadauth_pgbouncer_auth_type_query(rolename text)
    returns TABLE(has_sec_label text, username text, user_cred text, error_message text)
    language plpgsql
as
$$
	DECLARE _has_sec_label text;
    DECLARE _pgaadauth_lib_loaded text;
    DECLARE _pgaadauth_extension_created text;
    DECLARE _password_auth_enabled text;
	DECLARE _username text;
	DECLARE _user_cred text;
	DECLARE _error_message text;
	BEGIN
		_has_sec_label := '0'; -- indicates if user has security label associated, thus can login with token.
        _pgaadauth_lib_loaded := '0'; -- indicates if pgaadauth shared library is loaded.
        _pgaadauth_extension_created := '0'; -- indicates if the extension is created. Othwerwise, token validation cannot be made.
        _password_auth_enabled := 'on'; -- indicates if the server supports password authentication or not.
		_username := ''; -- indicates if the role exists in the database.
		_user_cred := ''; -- indicates if the credentials can be obtained from the pg_shadow table. Should only apply for Non-AAD roles.
		_error_message := '';

		-- prepare local variables that are going to be used:
        IF EXISTS (SELECT *
                    FROM pg_seclabels
                    WHERE REPLACE(objname, '"', '') = roleName AND provider = 'pgaadauth-int') THEN
            _has_sec_label := '1';
        END IF;

        IF EXISTS (SELECT *
                FROM current_setting('shared_preload_libraries')
                WHERE current_setting like '%pgaadauth%') THEN
            _pgaadauth_lib_loaded := '1';
        END IF;

        SELECT setting INTO _password_auth_enabled
            FROM pg_settings
            WHERE name = 'pgaadauth.password_auth_enabled';

        IF EXISTS (SELECT 1
                FROM pg_extension
                WHERE extname = 'pgaadauth') THEN
			_pgaadauth_extension_created := '1';
		END IF;

        SELECT usename, passwd INTO _username, _user_cred
            FROM pg_shadow
            WHERE usename = rolename AND (valuntil IS NULL OR valuntil > now());

        IF (_username = '' OR _username IS NULL) IS TRUE THEN
            _error_message := 'no such user';
		ELSIF _has_sec_label = '1' THEN
			IF _pgaadauth_lib_loaded = '0' THEN
				_error_message = 'Azure Active Directory authentication is disabled on the server.';
			END IF;
			IF _pgaadauth_extension_created = '0' THEN
				_error_message = 'pgaadauth extension is not created on the target database.';
			END IF;
		ELSE
			IF _password_auth_enabled = 'off' THEN
				_error_message = 'Password authentication is disabled on the server.';
			END IF;
		END IF;

		RETURN QUERY
			SELECT _has_sec_label, _username, _user_cred, _error_message;
	END
$$;

alter function pgaadauth_pgbouncer_auth_type_query(text) owner to azuresu;

