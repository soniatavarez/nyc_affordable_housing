create function pgaadauth_revoke_principal_group_membership(groupname text, grouproleoid oid, groupobjectid text, localrolename text, localrolesoid oid, iscurrentroleadmin boolean, adminrolename text, adminroleid oid, groupmembershipscount integer, azure_ad_user_roleoid oid, iscpg boolean) returns void
    language plpgsql
as
$$
    DECLARE query text;
    BEGIN
        --- REVOKING access to the group's role just in case there are some triggers
        query := 'REVOKE ' || quote_ident(groupName) || ' FROM ' || quote_ident(localRoleName);
        EXECUTE query;

        IF groupMembershipsCount = 1 THEN
            -- This role has no other exposed relation other than the group
            -- It is okay to drop this role
            IF isCPG THEN
                query := 'REVOKE azure_ad_user FROM '  || quote_ident(localRoleName);
                EXECUTE query;

                DELETE FROM pg_auth_members
                WHERE
                    member=localRolesOid::oid AND
                    roleid=azure_ad_user_roleOid::oid;

                DELETE FROM pg_dist_authinfo
                    WHERE rolename = localRoleName AND nodeid=0;

                DELETE FROM pg_dist_authinfo
                    WHERE rolename = localRoleName AND nodeid=-1;
            END IF;

            IF isCurrentRoleAdmin THEN
                query := 'REVOKE ' || quote_ident(adminRoleName) || ' FROM ' || quote_ident(localRoleName);
                EXECUTE query;
                DELETE FROM pg_auth_members
                WHERE
                    member=localRolesOid::oid AND
                    roleid=adminRoleId::oid;
            END IF;

            --- This role is not a member of any other group
            query := 'DROP ROLE ' || quote_ident(localRoleName);
            EXECUTE query;
        END IF;

        DELETE FROM pg_auth_members WHERE member=localRolesOid::oid AND roleid=groupRoleOid::oid;
    END;
$$;

alter function pgaadauth_revoke_principal_group_membership(text, oid, text, text, oid, boolean, text, oid, integer, oid, boolean) owner to azuresu;

