create function pgaadauth_sync_roles_for_group_members(groupobjectid text) returns void
    language plpgsql
as
$$
    DECLARE groupName text;
    DECLARE groupRoleOid  text;
    DECLARE eachRow RECORD;
    DECLARE securityLabel text := 'aadauth';
    DECLARE createRoleQuery text;
    DECLARE securityLabelQuery text;
    DECLARE newRoleName text;
    DECLARE query text;
    DECLARE azure_ad_user_roleOid oid;
    DECLARE isAdmin boolean;
    DECLARE isMfa boolean;
    DECLARE isCPG boolean := FALSE;
    DECLARE isFlex boolean := FALSE;
    DECLARE adminRoleId oid;
    DECLARE adminRoleName text;
    BEGIN
        --- We need the groupName and group's role-oid
        --- given a groupObjectId corresponding to an aad group,
        --- we get group's name and role-oid from the pg_seclabels.
        --- This information is populated ONLY if the group has been onboarded
        --- through the aad methods(create_principle...).
        SELECT
            pg_roles.rolname,
            pg_roles.oid,
            pg_seclabels.label ~ '\,admin' AS isAdmin,
            pg_seclabels.label ~ '\,mfa' AS isMfa
        INTO groupName, groupRoleOid, isAdmin, isMfa
        FROM pg_roles
            INNER JOIN pg_seclabels -- The group's aad-oid is part of the label
            ON pg_roles.oid = pg_seclabels.objoid
        WHERE pg_seclabels.label ~ ('oid=' || groupObjectId);

        SELECT pg_roles.oid INTO azure_ad_user_roleOid FROM pg_roles WHERE rolname='azure_ad_user';

        IF current_user = 'postgres'
        THEN
            isCPG := TRUE;
            adminRoleName := 'postgres';
        ELSIF current_user = 'azuresu' THEN
            isFlex := TRUE;
            adminRoleName := 'azure_pg_admin';
        ELSE
            RAISE EXCEPTION 'This function can only be called by the superuser that is either azuresu(Flex) or postgres(CPG)';
        END IF;

        SELECT pg_roles.oid INTO adminRoleId FROM pg_roles WHERE rolname=adminRoleName;

        --- We only care about
        --- 1. AAD Principals that are newly added to the AAD group
        --- 2. AAD Principals that are removed from the AAD group
        --- Those AAD principals that were previously onboarded don't matter since
        --- they are already in the database.
        --- We collect the needed diff b/w AAD principals and db roles in a temp table here
        DROP TABLE IF EXISTS aad_vs_local_diff;
        CREATE TEMP TABLE aad_vs_local_diff AS
        WITH aad_members AS (
            SELECT
                aad_oid,
                aad_type,
                aad_displayName,
                aad_userPrincipalName
            FROM pgaadauth_get_group_members(groupObjectId)
        ),
        local_aad_roles AS (
            --- A local role's AAD object id is part of the security label(pg_seclabels) - needed
            --- A local role's group membership is part of pg_auth_members - needed
            SELECT
                pg_roles.oid as localRolesOid,
                pg_roles.rolname as localRoleName,
                SUBSTRING(pg_seclabels.label FROM '[a-zA-Z=0-9\-_,]*oid=([a-zA-Z0-9\-]+)[a-zA-Z=0-9\-@,_]*') as localRolesAadOid
            FROM pg_roles
            INNER JOIN pg_auth_members
                ON pg_roles.oid=pg_auth_members.member
            INNER JOIN pg_seclabels
                ON pg_roles.oid=pg_seclabels.objoid
            WHERE
                pg_auth_members.roleid=groupRoleOid::oid AND
                pg_seclabels.label ~ ('type=(user|group|service),oid=[0-9a-f\-]+')
        )
        (SELECT *
            FROM aad_members
            LEFT JOIN
                local_aad_roles ON aad_members.aad_oid=local_aad_roles.localRolesAadOid
            --- These AAD group members don't have a local role
            WHERE local_aad_roles.localRolesAadOid IS NULL
        ) UNION (
            SELECT *
            FROM aad_members
            RIGHT JOIN
                local_aad_roles ON aad_members.aad_oid=local_aad_roles.localRolesAadOid
            --- These local roles don't have a AAD group member anymore
            WHERE aad_members.aad_oid IS NULL
        );

        --- Add Principals that are may be new
        FOR eachRow IN (SELECT
                aad_oid,
                aad_displayname,
                aad_type,
                aad_userPrincipalName,
                localRolesOid,
                localRoleName,
                localRolesAadOid,
                (CASE WHEN seclabels.objoid IS NULL THEN TRUE ELSE FALSE END) AS needsOnboarding
            FROM aad_vs_local_diff
            LEFT JOIN (
                SELECT
                    pg_seclabels.label AS label,
                    pg_seclabels.objoid AS objoid
                FROM pg_seclabels
                INNER JOIN pg_roles
                    ON pg_roles.oid=pg_seclabels.objoid
            ) seclabels
            ON seclabels.label LIKE '%aadauth%oid='||aad_vs_local_diff.aad_oid||'%'
            WHERE aad_oid IS NOT NULL)
        LOOP
            --- This aad principal may have been turned into a role on the database either manually
            --- or as a part of someother group which was previously sync'd.
            IF eachRow.aad_type = 'user' THEN
                newRoleName := eachRow.aad_userPrincipalName;
            ELSE
                newRoleName := eachRow.aad_oid;
            END IF;

            --- If this Role exists through other group, then just grant group membership
            IF eachRow.needsOnboarding THEN
                securityLabel := 'aadauth';
                securityLabel := CONCAT(securityLabel, CONCAT(',oid=', eachRow.aad_oid));

                IF eachRow.aad_type = 'service' THEN
                    securityLabel := CONCAT(securityLabel, ',type=service');
                ELSIF eachRow.aad_type = 'user' THEN
                    securityLabel := CONCAT(securityLabel, ',type=user');
                ELSE
                    securityLabel := CONCAT(securityLabel, CONCAT(',type=', 'unknown'));
                END IF;

                createRoleQuery := FORMAT('CREATE ROLE %1$s LOGIN',  quote_ident(newRoleName));

                --- If a group role has admin privileges and it admin privileges are revoked
                --- then the child roles may retain admin privileges. This is a security risk!
                --- TODO: Model this scenario and patch in future.
                IF isAdmin IS TRUE THEN
                    IF isCPG IS TRUE THEN
                        createRoleQuery := CONCAT(createRoleQuery, ' CREATEROLE CREATEDB IN ROLE postgres');
                    ELSIF isFlex IS TRUE THEN
                        createRoleQuery := CONCAT(createRoleQuery, ' CREATEROLE CREATEDB IN ROLE azure_pg_admin');
                    END IF;
                    securityLabel := CONCAT(securityLabel, ',admin');
                END IF;

                createRoleQuery := CONCAT(createRoleQuery, ';');

                --- BUG!: If an aad group is formerly sync'd as non admin and non mfa
                --- but another group is sync'd as admin and mfa,
                --- the role will not have mfa or admin privileges.
                --- ASSUMPTION: No admin group will share members with a non admin group
                IF isMfa IS TRUE THEN
                    securityLabel := CONCAT(securityLabel, ',mfa');
                END IF;

                securityLabel := CONCAT(securityLabel, ',extensionmanaged,novalidate');
                EXECUTE createRoleQuery;

                IF isCPG THEN
                    query := 'GRANT azure_ad_user TO ' || quote_ident(newRoleName);
                    EXECUTE query;

                    INSERT INTO pg_dist_authinfo (nodeid, rolename, authinfo)
                        VALUES
                            (0, newRoleName, 'sslcert=/certs/postgresql-cert.pem sslkey=/certs/postgresql-key.pem'),
                            (-1, newRoleName, 'sslmode=require sslcert=/certs/postgresql-cert.pem sslkey=/certs/postgresql-key.pem') ON CONFLICT DO NOTHING;
                END IF;

                securityLabelQuery := FORMAT('SECURITY LABEL FOR "pgaadauth" ON ROLE %1$s IS %2$s', quote_ident(newRoleName) , quote_literal(securityLabel));
                EXECUTE securityLabelQuery;
            END IF;
            --- Make this role to inherit from the group role
            query := 'GRANT ' || quote_ident(groupName) || ' TO ' || quote_ident(newRoleName);
            EXECUTE query;

        END LOOP;

        -- Deleted AAD group members / database role with no other group memberships
        -- can be deleted from the database
        FOR eachRow IN (
            SELECT
                counted_roles.membershipCount,
                counted_roles.localRolesOid,
                counted_roles.localRoleName,
                pg_seclabels.label AS localSecLabel,
                (pg_seclabels.label ~ '\,admin') AS currentRoleIsAdmin
            FROM (
                SELECT
                    COUNT(*) membershipCount,
                    localRolesOid,
                    localRoleName
                FROM aad_vs_local_diff
                INNER JOIN pg_auth_members
                    ON pg_auth_members.member=aad_vs_local_diff.localRolesOid
                WHERE
                    aad_vs_local_diff.aad_oid IS NULL AND
                    pg_auth_members.roleid != azure_ad_user_roleOid::oid AND
                    pg_auth_members.roleid != adminRoleId::oid
                GROUP BY localRolesOid, localRoleName) counted_roles
            INNER JOIN pg_seclabels
                ON pg_seclabels.objoid=counted_roles.localRolesOid
            WHERE
                pg_seclabels.label ~ 'extensionmanaged' AND
                pg_seclabels.label ~ 'aadauth')
        LOOP
            PERFORM pgaadauth_revoke_principal_group_membership(
                groupName::text,
                groupRoleOid::oid,
                groupObjectId::text,
                eachRow.localRoleName::text,
                eachRow.localRolesOid::oid,
                eachRow.currentRoleIsAdmin::boolean,
                adminRoleName::text,
                adminRoleId::oid,
                eachRow.membershipCount::integer,
                azure_ad_user_roleOid::oid,
                isCPG::boolean);
        END LOOP;
        DROP TABLE IF EXISTS aad_vs_local_diff;
    END;
$$;

alter function pgaadauth_sync_roles_for_group_members(text) owner to azuresu;

